Svi labosi su predani i nitko nije kukao, najvjerojatnije nisu ni pogledani, u u 3.labosu bi kao trebali za svoj procesor 
gledati ima li neke linije ili ne -.-, ali nije neophodno :)